export const APP_CONFIG = {
  name: 'AgriConnect',
  description: 'Empowering Farmers with Technology',
  version: '1.0.0',
  author: 'AgriConnect Team',
  contact: {
    email: 'support@agriconnect.com',
    phone: '+91 1234567890',
    address: 'India'
  }
};

export const ROUTES = {
  HOME: '/',
  WEATHER: '/weather',
  MANDI_RATES: '/mandi-rates',
  SELL_PRODUCE: '/sell-produce',
  DASHBOARD: '/dashboard',
  LOGIN: '/login',
  SIGNUP: '/signup'
};

export const PRODUCE_CATEGORIES = [
  'Cereals',
  'Vegetables', 
  'Fruits',
  'Pulses',
  'Spices',
  'Cash Crops',
  'Dairy',
  'Poultry',
  'Other'
];

export const UNITS = [
  'kg',
  'quintal', 
  'ton',
  'piece',
  'dozen',
  'liter'
];

export const PRODUCE_STATUS = {
  AVAILABLE: 'available',
  SOLD: 'sold',
  RESERVED: 'reserved'
} as const;

export const WEATHER_CONDITIONS = {
  SUNNY: 'sunny',
  CLOUDY: 'cloudy',
  PARTLY_CLOUDY: 'partly cloudy',
  RAINY: 'rainy'
} as const;