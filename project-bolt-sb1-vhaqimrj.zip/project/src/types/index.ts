export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  location?: string;
  farm_size?: number;
  created_at: string;
}

export interface Produce {
  id: string;
  user_id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  price_per_unit: number;
  description?: string;
  location: string;
  harvest_date: string;
  expiry_date?: string;
  image_url?: string;
  status: 'available' | 'sold' | 'reserved';
  created_at: string;
}

export interface MandiRate {
  id: string;
  commodity: string;
  market: string;
  min_price: number;
  max_price: number;
  modal_price: number;
  unit: string;
  date: string;
  created_at: string;
}

export interface WeatherData {
  location: string;
  temperature: number;
  humidity: number;
  rainfall: number;
  wind_speed: number;
  condition: string;
  forecast: {
    date: string;
    temp_min: number;
    temp_max: number;
    condition: string;
    rainfall_chance: number;
  }[];
}

export interface Transaction {
  id: string;
  buyer_id: string;
  seller_id: string;
  produce_id: string;
  quantity: number;
  total_amount: number;
  status: 'pending' | 'completed' | 'cancelled';
  created_at: string;
}