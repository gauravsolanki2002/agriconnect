import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Sprout, 
  CloudRain, 
  TrendingUp, 
  ShoppingCart, 
  Users, 
  BarChart3,
  CheckCircle,
  ArrowRight,
  Star
} from 'lucide-react';

const Home: React.FC = () => {
  const features = [
    {
      icon: CloudRain,
      title: 'Weather Forecast',
      description: 'Get accurate weather predictions to plan your farming activities effectively.',
      link: '/weather'
    },
    {
      icon: TrendingUp,
      title: 'Mandi Rates',
      description: 'Real-time market prices for all major crops across different mandis.',
      link: '/mandi-rates'
    },
    {
      icon: ShoppingCart,
      title: 'Sell Produce',
      description: 'Connect directly with buyers and get the best prices for your harvest.',
      link: '/sell-produce'
    },
    {
      icon: BarChart3,
      title: 'Analytics Dashboard',
      description: 'Track your sales, monitor market trends, and make data-driven decisions.',
      link: '/dashboard'
    }
  ];

  const benefits = [
    'Direct connection with buyers',
    'Real-time market information',
    'Weather-based farming guidance',
    'Transparent pricing',
    'Secure transactions',
    'Mobile-friendly platform'
  ];

  const testimonials = [
    {
      name: 'Rajesh Kumar',
      location: 'Punjab',
      text: 'AgriConnect helped me get 20% better prices for my wheat crop. The platform is easy to use and very reliable.',
      rating: 5
    },
    {
      name: 'Priya Sharma',
      location: 'Maharashtra',
      text: 'The weather forecasts are very accurate. I can now plan my irrigation schedule much better.',
      rating: 5
    },
    {
      name: 'Suresh Patel',
      location: 'Gujarat',
      text: 'Excellent platform for selling vegetables. Found buyers within hours of listing my produce.',
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-green-600 via-green-700 to-green-800 text-white">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Empowering Farmers with
              <span className="block text-green-200">Modern Technology</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-green-100 max-w-3xl mx-auto">
              Connect with buyers, access real-time market data, get weather forecasts, 
              and grow your agricultural business with AgriConnect.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/signup"
                className="px-8 py-4 bg-white text-green-700 font-semibold rounded-lg hover:bg-green-50 transition-colors inline-flex items-center justify-center"
              >
                Get Started Today
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link
                to="/weather"
                className="px-8 py-4 border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-green-700 transition-colors"
              >
                Explore Features
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Everything You Need to Succeed
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our comprehensive platform provides all the tools and information 
              modern farmers need to thrive in today's market.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Link
                key={index}
                to={feature.link}
                className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow group"
              >
                <div className="p-3 bg-green-100 rounded-lg w-fit mb-4 group-hover:bg-green-200 transition-colors">
                  <feature.icon className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Why Choose AgriConnect?
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Join thousands of farmers who have transformed their agricultural 
                business with our innovative platform.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/2132250/pexels-photo-2132250.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Farmer using technology"
                className="rounded-xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-green-600 text-white p-6 rounded-lg shadow-xl">
                <div className="flex items-center space-x-2">
                  <Users className="h-8 w-8" />
                  <div>
                    <div className="text-2xl font-bold">10,00+</div>
                    <div className="text-green-200">Active Farmers</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What Farmers Say About Us
            </h2>
            <p className="text-xl text-gray-600">
              Real stories from real farmers who have benefited from AgriConnect
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-lg">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4 italic">
                  "{testimonial.text}"
                </p>
                <div>
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-500">{testimonial.location}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-green-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Transform Your Farming Business?
          </h2>
          <p className="text-xl mb-8 text-green-100 max-w-2xl mx-auto">
            Join AgriConnect today and start connecting with buyers, 
            accessing market data, and growing your agricultural success.
          </p>
          <Link
            to="/signup"
            className="px-8 py-4 bg-white text-green-600 font-semibold rounded-lg hover:bg-green-50 transition-colors inline-flex items-center"
          >
            Start Your Journey
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;