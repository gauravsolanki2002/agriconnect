import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Search, 
  Filter,
  MapPin,
  Calendar,
  BarChart3,
  RefreshCw
} from 'lucide-react';

interface MandiRate {
  id: string;
  commodity: string;
  market: string;
  min_price: number;
  max_price: number;
  modal_price: number;
  unit: string;
  date: string;
  change: number;
  change_percent: number;
}

const MandiRates: React.FC = () => {
  const [rates, setRates] = useState<MandiRate[]>([]);
  const [filteredRates, setFilteredRates] = useState<MandiRate[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMarket, setSelectedMarket] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [loading, setLoading] = useState(true);

  // Mock data - In production, this would come from a real API
  const mockRates: MandiRate[] = [
    {
      id: '1',
      commodity: 'Wheat',
      market: 'Delhi',
      min_price: 2100,
      max_price: 2300,
      modal_price: 2200,
      unit: 'Quintal',
      date: '2024-01-15',
      change: 50,
      change_percent: 2.3
    },
    {
      id: '2',
      commodity: 'Rice',
      market: 'Mumbai',
      min_price: 3500,
      max_price: 3800,
      modal_price: 3650,
      unit: 'Quintal',
      date: '2024-01-15',
      change: -25,
      change_percent: -0.7
    },
    {
      id: '3',
      commodity: 'Onion',
      market: 'Pune',
      min_price: 1200,
      max_price: 1500,
      modal_price: 1350,
      unit: 'Quintal',
      date: '2024-01-15',
      change: 100,
      change_percent: 8.0
    },
    {
      id: '4',
      commodity: 'Tomato',
      market: 'Bangalore',
      min_price: 800,
      max_price: 1200,
      modal_price: 1000,
      unit: 'Quintal',
      date: '2024-01-15',
      change: -150,
      change_percent: -13.0
    },
    {
      id: '5',
      commodity: 'Potato',
      market: 'Kolkata',
      min_price: 900,
      max_price: 1100,
      modal_price: 1000,
      unit: 'Quintal',
      date: '2024-01-15',
      change: 30,
      change_percent: 3.1
    },
    {
      id: '6',
      commodity: 'Sugarcane',
      market: 'Lucknow',
      min_price: 350,
      max_price: 380,
      modal_price: 365,
      unit: 'Quintal',
      date: '2024-01-15',
      change: 5,
      change_percent: 1.4
    }
  ];

  const markets = ['All', 'Delhi', 'Mumbai', 'Pune', 'Bangalore', 'Kolkata', 'Lucknow'];
  const categories = ['All', 'Cereals', 'Vegetables', 'Fruits', 'Cash Crops'];

  useEffect(() => {
    // Simulate API call
    setLoading(true);
    setTimeout(() => {
      setRates(mockRates);
      setFilteredRates(mockRates);
      setLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    let filtered = rates;

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(rate =>
        rate.commodity.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rate.market.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filter by market
    if (selectedMarket !== 'All') {
      filtered = filtered.filter(rate => rate.market === selectedMarket);
    }

    setFilteredRates(filtered);
  }, [searchTerm, selectedMarket, selectedCategory, rates]);

  const refreshRates = () => {
    setLoading(true);
    setTimeout(() => {
      // Simulate updated data with random changes
      const updatedRates = mockRates.map(rate => ({
        ...rate,
        modal_price: rate.modal_price + (Math.random() - 0.5) * 100,
        change: (Math.random() - 0.5) * 200,
        change_percent: (Math.random() - 0.5) * 10
      }));
      setRates(updatedRates);
      setLoading(false);
    }, 1000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading market rates...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Mandi Rates</h1>
          <p className="text-xl text-gray-600">
            Real-time market prices for agricultural commodities
          </p>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search commodity or market..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>

            {/* Market Filter */}
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <select
                value={selectedMarket}
                onChange={(e) => setSelectedMarket(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent appearance-none"
              >
                {markets.map(market => (
                  <option key={market} value={market}>{market}</option>
                ))}
              </select>
            </div>

            {/* Category Filter */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent appearance-none"
              >
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>

            {/* Refresh Button */}
            <button
              onClick={refreshRates}
              className="flex items-center justify-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              <RefreshCw className="h-5 w-5" />
              <span>Refresh</span>
            </button>
          </div>
        </div>

        {/* Market Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Markets Tracked</p>
                <p className="text-2xl font-bold text-gray-900">{markets.length - 1}</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <BarChart3 className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Commodities</p>
                <p className="text-2xl font-bold text-gray-900">{rates.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Calendar className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Last Updated</p>
                <p className="text-2xl font-bold text-gray-900">Today</p>
              </div>
            </div>
          </div>
        </div>

        {/* Rates Table */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Current Market Rates</h3>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Commodity
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Market
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Modal Price
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Min - Max
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Change
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Unit
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredRates.map((rate) => (
                  <tr key={rate.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900">{rate.commodity}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 text-gray-400 mr-1" />
                        <span className="text-gray-900">{rate.market}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-lg font-semibold text-gray-900">
                        ₹{rate.modal_price.toFixed(0)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-600">
                        ₹{rate.min_price} - ₹{rate.max_price}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`flex items-center space-x-1 ${
                        rate.change >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {rate.change >= 0 ? (
                          <TrendingUp className="h-4 w-4" />
                        ) : (
                          <TrendingDown className="h-4 w-4" />
                        )}
                        <span className="font-medium">
                          {rate.change >= 0 ? '+' : ''}₹{rate.change.toFixed(0)}
                        </span>
                        <span className="text-sm">
                          ({rate.change_percent >= 0 ? '+' : ''}{rate.change_percent.toFixed(1)}%)
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {rate.unit}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredRates.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">No rates found matching your criteria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MandiRates;