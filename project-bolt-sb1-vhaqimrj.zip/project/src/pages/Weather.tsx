import React, { useState, useEffect } from 'react';
import { 
  Cloud, 
  Sun, 
  CloudRain, 
  Wind, 
  Droplets, 
  Thermometer,
  MapPin,
  Calendar,
  TrendingUp
} from 'lucide-react';

interface WeatherData {
  location: string;
  temperature: number;
  humidity: number;
  rainfall: number;
  wind_speed: number;
  condition: string;
  forecast: {
    date: string;
    temp_min: number;
    temp_max: number;
    condition: string;
    rainfall_chance: number;
  }[];
}

const Weather: React.FC = () => {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [selectedLocation, setSelectedLocation] = useState('Delhi');
  const [loading, setLoading] = useState(true);

  const locations = [
    'Delhi', 'Mumbai', 'Bangalore', 'Chennai', 'Kolkata', 
    'Hyderabad', 'Pune', 'Ahmedabad', 'Jaipur', 'Lucknow'
  ];

  // Mock weather data - In production, this would come from a weather API
  const mockWeatherData: WeatherData = {
    location: selectedLocation,
    temperature: 28,
    humidity: 65,
    rainfall: 2.5,
    wind_speed: 12,
    condition: 'Partly Cloudy',
    forecast: [
      { date: '2024-01-15', temp_min: 22, temp_max: 30, condition: 'Sunny', rainfall_chance: 10 },
      { date: '2024-01-16', temp_min: 24, temp_max: 32, condition: 'Partly Cloudy', rainfall_chance: 20 },
      { date: '2024-01-17', temp_min: 20, temp_max: 28, condition: 'Rainy', rainfall_chance: 80 },
      { date: '2024-01-18', temp_min: 23, temp_max: 29, condition: 'Cloudy', rainfall_chance: 40 },
      { date: '2024-01-19', temp_min: 25, temp_max: 31, condition: 'Sunny', rainfall_chance: 5 },
    ]
  };

  useEffect(() => {
    // Simulate API call
    setLoading(true);
    setTimeout(() => {
      setWeatherData(mockWeatherData);
      setLoading(false);
    }, 1000);
  }, [selectedLocation]);

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'sunny':
        return <Sun className="h-8 w-8 text-yellow-500" />;
      case 'rainy':
        return <CloudRain className="h-8 w-8 text-blue-500" />;
      case 'cloudy':
      case 'partly cloudy':
        return <Cloud className="h-8 w-8 text-gray-500" />;
      default:
        return <Sun className="h-8 w-8 text-yellow-500" />;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const farmingTips = [
    {
      condition: 'Sunny',
      tip: 'Perfect weather for harvesting and field preparation. Ensure adequate irrigation.'
    },
    {
      condition: 'Rainy',
      tip: 'Good for transplanting. Avoid heavy machinery use. Check for waterlogging.'
    },
    {
      condition: 'Cloudy',
      tip: 'Ideal for spraying pesticides and fertilizers. Monitor humidity levels.'
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading weather data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Weather Forecast</h1>
          <p className="text-xl text-gray-600">
            Get accurate weather information to plan your farming activities
          </p>
        </div>

        {/* Location Selector */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-4">
            <MapPin className="h-5 w-5 text-gray-600" />
            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              {locations.map((location) => (
                <option key={location} value={location}>
                  {location}
                </option>
              ))}
            </select>
          </div>
        </div>

        {weatherData && (
          <>
            {/* Current Weather */}
            <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="text-center lg:text-left">
                  <div className="flex items-center justify-center lg:justify-start space-x-4 mb-4">
                    {getWeatherIcon(weatherData.condition)}
                    <div>
                      <h2 className="text-3xl font-bold text-gray-900">
                        {weatherData.temperature}°C
                      </h2>
                      <p className="text-lg text-gray-600">{weatherData.condition}</p>
                    </div>
                  </div>
                  <p className="text-gray-600 flex items-center justify-center lg:justify-start">
                    <MapPin className="h-4 w-4 mr-1" />
                    {weatherData.location}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Droplets className="h-5 w-5 text-blue-600" />
                      <span className="text-sm font-medium text-gray-700">Humidity</span>
                    </div>
                    <p className="text-2xl font-bold text-blue-600">{weatherData.humidity}%</p>
                  </div>
                  
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <CloudRain className="h-5 w-5 text-green-600" />
                      <span className="text-sm font-medium text-gray-700">Rainfall</span>
                    </div>
                    <p className="text-2xl font-bold text-green-600">{weatherData.rainfall}mm</p>
                  </div>
                  
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Wind className="h-5 w-5 text-purple-600" />
                      <span className="text-sm font-medium text-gray-700">Wind Speed</span>
                    </div>
                    <p className="text-2xl font-bold text-purple-600">{weatherData.wind_speed} km/h</p>
                  </div>
                  
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Thermometer className="h-5 w-5 text-orange-600" />
                      <span className="text-sm font-medium text-gray-700">Feels Like</span>
                    </div>
                    <p className="text-2xl font-bold text-orange-600">{weatherData.temperature + 2}°C</p>
                  </div>
                </div>
              </div>
            </div>

            {/* 5-Day Forecast */}
            <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <Calendar className="h-6 w-6 mr-2" />
                5-Day Forecast
              </h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                {weatherData.forecast.map((day, index) => (
                  <div key={index} className="bg-gray-50 p-4 rounded-lg text-center">
                    <p className="text-sm font-medium text-gray-600 mb-2">
                      {formatDate(day.date)}
                    </p>
                    <div className="flex justify-center mb-2">
                      {getWeatherIcon(day.condition)}
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{day.condition}</p>
                    <div className="text-sm">
                      <span className="font-bold text-gray-900">{day.temp_max}°</span>
                      <span className="text-gray-500 ml-1">{day.temp_min}°</span>
                    </div>
                    <p className="text-xs text-blue-600 mt-1">
                      {day.rainfall_chance}% rain
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Farming Tips */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <TrendingUp className="h-6 w-6 mr-2" />
                Farming Tips Based on Weather
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {farmingTips.map((tip, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-3">
                      {getWeatherIcon(tip.condition)}
                      <h4 className="font-semibold text-gray-900">{tip.condition} Weather</h4>
                    </div>
                    <p className="text-gray-600 text-sm">{tip.tip}</p>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Weather;